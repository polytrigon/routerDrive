// Auto-generated from style.css - do not hand-edit, regenerate instead.
// Served at GET /style.css by web_server.cpp.
#pragma once

static const char STYLE_CSS_SOURCE[] PROGMEM = R"STYLECSS(/* RouterDrive - shared stylesheet, served at GET /style.css.
   Kept as its own file (like dxf2svg.js) so styling lives in one place
   instead of being duplicated/hand-matched across every button and
   section. If you edit this, regenerate style_css.h to match - see the
   README's "Sketch layout" section. */

/* display:flex + min-height:100vh so <footer> (margin-top:auto, below) can
   anchor to the bottom of the page even when the rest of the content is
   short - on a normal/tall page this has no visible effect, footer just
   follows the content as usual. Everything except <footer> is wrapped in
   a <div class='page'> (see web_server.cpp) so body only has two direct
   children: flex items default to align-items:stretch, which would
   otherwise stretch every direct child - including inline-block elements
   like <button> that normally shrink-wrap their text - to the full page
   width. Wrapping the content keeps that stretch confined to .page and
   <footer> (both already full-width block elements, so no visible
   change), instead of blowing up buttons that aren't inside a <form>. */
body {
  font-family: sans-serif;
  max-width: 640px;
  margin: 2em auto;
  padding: 0 1em;
  color: #222;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  box-sizing: border-box;
}

h1 {
  margin-bottom: 0;
}

h2 {
  margin-top: 2.5em;
  margin-bottom: .5em;
}

.sub {
  color: #666;
  margin-top: .2em;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin: 1em 0;
}

td {
  padding: .4em .3em;
  border-bottom: 1px solid #ddd;
}

th {
  text-align: left;
  padding: .4em .3em;
  border-bottom: 2px solid #999;
}

/* Separates the cut-editor panel's per-selection controls from the
   file-level anchor control below them. A hairline rather than a colour
   change or a dimmed block: the anchor is not secondary or inactive, it
   just answers a different question than the controls above it. */
.panel-divider {
  border-top: 1px solid #ddd;
  margin: 1em 0 .9em;
}

/* File list column widths. Size, Cut type and Uploaded all get the same
   fixed width so they read as an evenly spaced block sitting at the right
   of the table, and Name - the longest, most variable, most worth-reading
   value - takes whatever is left. table-layout:fixed is what makes those
   widths authoritative rather than suggestions the browser re-weighs
   against the content. */
.file-table {
  table-layout: fixed;
}

.file-table .col-check {
  width: 2.2em;
}

.file-table .col-meta {
  width: 7em;
  white-space: nowrap;
}

/* A long filename wraps inside its own column instead of forcing the
   table wider than the page. */
.file-table td:nth-child(2) {
  overflow-wrap: anywhere;
}

/* Below roughly this width there isn't room for three fixed columns AND a
   readable name - holding the widths anyway squeezes Name down to a couple
   of characters and wraps filenames one letter per line. So on a phone the
   even-spacing goal gives way: hand column sizing back to the browser and
   let the metadata columns take only what their content needs (they stay
   nowrap, so they still can't wrap mid-value), leaving the rest to Name. */
@media (max-width: 560px) {
  .file-table {
    table-layout: auto;
  }
  .file-table .col-check,
  .file-table .col-meta {
    width: auto;
  }
}

input {
  width: 100%;
  box-sizing: border-box;
  padding: .4em;
}

/* ...but not checkboxes. The rule above is meant for fields you type
   into; a checkbox isn't one, and full width + text-field padding does
   nothing useful to it. Left at the browser default a checkbox renders
   around 13px, which is noticeably small next to this page's type and a
   poor tap target on a phone - so size it in em (scaling with the text
   around it) and give it the page's own blue rather than the browser's
   accent color. */
input[type='checkbox'] {
  width: 1.3em;
  height: 1.3em;
  padding: 0;
  margin: 0;
  vertical-align: middle;
  accent-color: #1437c9;
  cursor: pointer;
}

/* One consistent look for every button on the page, regardless of
   whether it's a form's type='submit' or a plain type='button' handled
   by JS - browsers style those two differently on their own otherwise.
   Pill-shaped (border-radius well past half the button's own height
   always reads as fully rounded, regardless of exact padding/font
   size) with bold white text on a solid indigo-blue, matching the
   reference "Add to cart" style the user asked to match. */
button {
  padding: .85em 1.75em;
  cursor: pointer;
  background: #1437c9;
  color: #fff;
  border: none;
  border-radius: 10px;
  font-size: 1em;
  font-weight: 600;
}

button:hover {
  background: #112fab;
}

button:active {
  background: #0e268d;
}

/* Delete/Move on the file list start disabled until a row is checked
   (see updateBatchButtons() in the page script) - greyed out and inert
   rather than fully hidden, so their spot in the layout stays put. */
button:disabled,
button:disabled:hover,
button:disabled:active {
  background: #ccc;
  color: #888;
  cursor: not-allowed;
}

/* Delete/Move on the file list, and the Confirm/Cancel pair in the move
   panel, are smaller than other buttons - they sit in a tight row (or
   directly below one) and don't need to be as prominent as the page's
   primary actions (Upload, Convert & upload). */
#deleteBtn,
#moveBtn,
#renameBtn,
#confirmMoveBtn,
#cancelMoveBtn,
#confirmRenameBtn,
#applyToSelectedBtn {
  padding: .4em .9em;
  font-size: .85em;
}

/* Larger, more touch-friendly sizing for the Upload section's file picker
   and units dropdown - their native browser-default sizing reads noticeably
   smaller/lower-key than the button next to them. Also gives the file
   input's native "Choose file" control the same look as the page's other
   buttons instead of the browser's plain default. */
select,
input[type='file'] {
  font-size: 1.05em;
  padding: .6em;
  border: 1px solid #ccc;
  border-radius: 4px;
  background: #fff;
}

/* "No file chosen" text specifically (not <select>s, which share the rule
   above) - lighter grey than the page's default body text so it reads as
   secondary/placeholder-like next to the button. The button below sets
   its own color explicitly, so this doesn't affect it. */
input[type='file'] {
  color: #888;
}

/* Gap before "No file chosen": a solid white border-right on the button
   (matching the input's own #fff background above), NOT margin-right and
   NOT a transparent+background-clip border - both were tried first and
   both failed on the user's real device/browser even though they worked
   correctly in this sandbox's Chromium: margin-right produced no visible
   gap at all, and a transparent border with background-clip:padding-box
   (meant to reserve space without painting over it) instead painted the
   "invisible" border area solid blue - background-clip isn't reliably
   honored on this native ::file-selector-button pseudo-element in every
   browser. Painting the border-right solid #fff instead of leaving it
   transparent sidesteps that: it doesn't need clipping to look invisible,
   it just blends into the input's own white background directly, so it
   works regardless of whether the browser supports clipping this
   pseudo-element's background. The button's own visible size/shape/
   centered "Choose Files" text (governed by padding, not border) is
   unaffected - only the white gap after it grows. */
input[type='file']::file-selector-button {
  font-size: 1em;
  padding: .5em 1em;
  border: none;
  border-right: .5em solid #fff;
  border-radius: 4px;
  background: #1437c9;
  color: #fff;
  cursor: pointer;
}

input[type='file']::file-selector-button:hover {
  background: #112fab;
}

/* Explicit full-width treatment for the page's two or three primary
   call-to-action controls (Convert & upload, its units dropdown, Restart
   device) - NOT the default for every button/select (Delete selected,
   Search, the footer's link-btn stay their natural shrink-to-fit size).
   Used to happen by accident everywhere via a body{display:flex} quirk;
   now it's applied deliberately just where it's wanted. */
.full-width {
  width: 100%;
  box-sizing: border-box;
}

.status {
  margin: .4em 0;
}

.dot {
  display: inline-block;
  width: .7em;
  height: .7em;
  border-radius: 50%;
  margin-right: .3em;
}

.dot-ok {
  background: #0a0;
}

.dot-bad {
  background: #b00;
}

.search {
  margin: .6em 0;
}

.search input {
  width: auto;
  display: inline-block;
}

.pager {
  margin: .5em 0;
}

.pager a {
  margin: 0 .4em;
}

/* Makes a <button> look like a plain muted text link instead of the
   page's normal blue buttons - for low-key, easy-to-ignore controls like
   the status LED's footer toggle. */
.link-btn {
  background: none;
  border: none;
  padding: 0;
  color: #999;
  text-decoration: underline;
  cursor: pointer;
  font-size: inherit;
  font-family: inherit;
  font-weight: normal; /* the base button rule is bold now (pill CTA
    style) - .link-btn is meant to read as a plain text link, not a
    button, so it opts back out */
}

.link-btn:hover,
.link-btn:active {
  background: none;
  color: #666;
}

/* Cut depth's value input and its unit dropdown share one row instead of
   stacking - the unit picker only needs a small slice of the width, not
   a full line to itself like the page's other controls. */
.depth-row {
  display: flex;
  gap: .5em;
}

.depth-row input {
  flex: 1 1 0;
  width: auto;
  min-width: 0;
}

.depth-row select {
  flex: 0 0 30%;
  width: 30%;
  box-sizing: border-box;
}

footer {
  margin-top: auto;
  padding-top: 2em;
  font-size: .8em;
  color: #999;
}

footer a {
  color: #999;
}

footer p {
  margin: .3em 0 0;
}

footer p:first-child {
  margin-top: 0;
}

/* Wraps the file list's bottom button row: Delete/Move on the left,
   "Delete this folder" on the right, all on one line (wraps on narrow
   screens instead of overlapping). */
/* Two groups pushed to opposite ends: the reversible actions (Rename,
   Move) on the left, and Delete - plus "Delete this folder" when there
   is one - alone on the right, deliberately nowhere near them. */
.file-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: .5em;
}

.file-actions-group {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: .5em;
}

/* Per-line cut editor modal, opened from a file list "Cut type" cell (see
   cutTypeCell/openCutEditorFromBtn in the page script). Same "dark
   backdrop + centered white box" shape as any standard modal - kept
   generic (.modal-overlay/.modal-box) in case a future feature wants a
   second dialog on this page, with .cut-editor-* for the pieces specific
   to this one. Hidden by default in markup (style='display:none');
   openCutEditor()/closeCutEditor() toggle it to/from 'flex' so the
   centering below actually applies. */
.modal-overlay {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, .5);
  align-items: center;
  justify-content: center;
  padding: 1em;
  box-sizing: border-box;
  z-index: 100;
}

.modal-box {
  background: #fff;
  border-radius: 10px;
  padding: 1.2em;
  width: 100%;
  max-width: 900px;
  max-height: 90vh;
  overflow-y: auto;
  box-sizing: border-box;
}

.cut-editor-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1em;
}

.cut-editor-header h3 {
  margin: 0;
}

.cut-editor-body {
  display: flex;
  flex-wrap: wrap;
  gap: 1em;
  margin-top: .5em;
}

/* Groups the rendered SVG with its color-key legend as one column (the
   "render window"), stacked vertically so the legend sits as a bar along
   the bottom of the viewer rather than in the side panel - kept as its
   own flex column, alongside .cut-editor-panel, inside .cut-editor-body. */
.cut-editor-viewer {
  flex: 3 1 300px;
  min-width: 260px;
  display: flex;
  flex-direction: column;
  gap: .5em;
}

/* The rendered SVG itself (injected by openCutEditor()) sizes to this
   pane via width:100%/height:auto set directly on the <svg> element - see
   the page script - so it scales down to fit regardless of the source
   drawing's own dimensions. */
.cut-editor-svg-wrap {
  border: 1px solid #ddd;
  border-radius: 6px;
  background: #fafafa;
  padding: .5em;
  box-sizing: border-box;
}

.cut-editor-panel {
  flex: 1 1 220px;
  min-width: 220px;
  max-width: 260px;
  box-sizing: border-box;
}

/* A horizontal bar along the bottom of the render window rather than a
   stacked list - entries spread out (justified) across the full width. */
.cut-legend {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  font-size: .85em;
  color: #555;
}

.cut-legend div {
  display: flex;
  align-items: center;
  gap: .4em;
  margin: .2em .6em .2em 0;
}

.cut-legend .swatch {
  display: inline-block;
  width: .8em;
  height: .8em;
  border-radius: 2px;
  flex: 0 0 auto;
}

/* The file list's batch-action dialogs - Rename (#renameOverlay) and
   Move (#moveOverlay). Both reuse the same .modal-overlay/.modal-box
   shell as the cut editor, just narrower: they hold a short list and a
   couple of controls, not a drawing. */
.dialog-narrow {
  max-width: 480px;
}

/* The "here's what you're about to act on" list - currently the files
   being moved. Plain, tight, and scrollable rather than letting a big
   selection push the dialog's own buttons off the screen. */
.dialog-file-list {
  margin: .2em 0 1em;
  padding-left: 1.2em;
  max-height: 40vh;
  overflow-y: auto;
}

.dialog-file-list li {
  word-break: break-all;
  margin: .15em 0;
}

/* One row per selected file: the current name as a small caption above
   the field you type the new one into, so it stays obvious which field
   belongs to which file when several are being renamed at once. */
.rename-row {
  margin-bottom: .9em;
}

.rename-row label {
  display: block;
  margin-bottom: .2em;
  word-break: break-all;
}

/* The name field and its fixed extension sit on one line, the field
   taking whatever width is left. The extension is deliberately plain
   text, not part of the input: you rename the file, not its type. */
.rename-field {
  display: flex;
  align-items: center;
  gap: .35em;
}

.rename-field .rename-stem {
  flex: 1 1 auto;
  min-width: 0;
  width: auto;
}

.rename-ext {
  flex: 0 0 auto;
  color: #666;
  font-family: inherit;
}
)STYLECSS";
